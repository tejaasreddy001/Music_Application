package com.example.musicv1

import android.graphics.drawable.Drawable

//data class MySuggest(var titleImage: Int)

data class MySuggest(var titleImage: Drawable, var songURL: String?, var songTitle:String?)